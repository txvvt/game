import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { io, Socket } from 'socket.io-client';
import { GameState, SearchResult } from '../types';
import { toast } from 'react-toastify';

interface GameContextType {
    socket: Socket | null;
    gameState: GameState | null;
    playerId: string | null;
    playerName: string;
    isAdmin: boolean;
    joinGame: (name: string, admin: boolean) => void;
    adminDrawTeams: () => void;
    adminAssignCaptains: (captainA: string, captainB: string) => void;
    captainHideRing: (targetPlayerId: string) => void;
    captainChooseInspector: (targetPlayerId: string) => void;
    inspectorSearch: (targetPlayerId: string, hand: 'left' | 'right') => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

const SOCKET_URL = '';

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [socket, setSocket] = useState<Socket | null>(null);
    const [gameState, setGameState] = useState<GameState | null>(null);
    const [playerId, setPlayerId] = useState<string | null>(null);
    const [playerName, setPlayerName] = useState<string>('');
    const [isAdmin, setIsAdmin] = useState<boolean>(false);

    useEffect(() => {
        const newSocket = io(SOCKET_URL, { autoConnect: false });
        setSocket(newSocket);

        return () => {
            newSocket.close();
        };
    }, []);

    useEffect(() => {
        if (!socket) return;

        socket.on('connect', () => {
            setPlayerId(socket.id!);
        });

        socket.on('GAME_STATE_UPDATE', (newState: GameState) => {
            setGameState(newState);
        });

        socket.on('SECRET_NOTIFICATION', (message: string) => {
            toast.info(message, {
                position: "top-center",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                theme: "dark",
            });
        });

        socket.on('SEARCH_RESULT', (result: SearchResult) => {
            if (result.success) {
                toast.success(result.message, { theme: "colored" });
            } else {
                toast.error(result.message, { theme: "colored" });
            }
        });

        return () => {
            socket.off('connect');
            socket.off('GAME_STATE_UPDATE');
            socket.off('SECRET_NOTIFICATION');
            socket.off('SEARCH_RESULT');
        };
    }, [socket]);

    const joinGame = (name: string, admin: boolean) => {
        if (socket) {
            socket.connect();
            socket.emit('JOIN_GAME', { name, isAdmin: admin });
            setPlayerName(name);
            setIsAdmin(admin);
        }
    };

    const adminDrawTeams = () => socket?.emit('ADMIN_DRAW_TEAMS');
    const adminAssignCaptains = (captainA: string, captainB: string) => socket?.emit('ADMIN_ASSIGN_CAPTAINS', { captainA, captainB });
    const captainHideRing = (targetPlayerId: string) => socket?.emit('CAPTAIN_HIDE_RING', { targetPlayerId });
    const captainChooseInspector = (targetPlayerId: string) => socket?.emit('CAPTAIN_CHOOSE_INSPECTOR', { targetPlayerId });
    const inspectorSearch = (targetPlayerId: string, hand: 'left' | 'right') => socket?.emit('INSPECTOR_SEARCH', { targetPlayerId, hand });

    return (
        <GameContext.Provider value={{
            socket, gameState, playerId, playerName, isAdmin,
            joinGame, adminDrawTeams, adminAssignCaptains,
            captainHideRing, captainChooseInspector, inspectorSearch
        }}>
            {children}
        </GameContext.Provider>
    );
};

export const useGame = () => {
    const context = useContext(GameContext);
    if (!context) throw new Error('useGame must be used within a GameProvider');
    return context;
};
