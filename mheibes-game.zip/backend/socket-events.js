const { gameActor, getPublicState } = require('./gameState');

module.exports = (io, socket) => {
    const broadcastState = () => {
        io.emit('GAME_STATE_UPDATE', getPublicState());
    };

    socket.on('JOIN_GAME', ({ name, isAdmin }) => {
        gameActor.send({ type: 'JOIN', socketId: socket.id, name, isAdmin: !!isAdmin });
        broadcastState();
    });

    socket.on('ADMIN_DRAW_TEAMS', () => {
        gameActor.send({ type: 'DRAW_TEAMS' });
        broadcastState();
    });

    socket.on('ADMIN_ASSIGN_CAPTAINS', ({ captainA, captainB }) => {
        gameActor.send({ type: 'ASSIGN_CAPTAINS', captainA, captainB });
        broadcastState();
    });

    socket.on('CAPTAIN_HIDE_RING', ({ targetPlayerId }) => {
        const currentState = gameActor.getSnapshot().context;

        // Determine which team this captain belongs to
        const isTeamACaptain = currentState.teams.A.captain === socket.id;
        const isTeamBCaptain = currentState.teams.B.captain === socket.id;

        if ((isTeamACaptain && currentState.currentTurn === 'A') ||
            (isTeamBCaptain && currentState.currentTurn === 'B')) {

            gameActor.send({ type: 'HIDE_RING', targetPlayerId });

            // notify only this target player secretly
            io.to(targetPlayerId).emit('SECRET_NOTIFICATION', 'المحيبس عندك! 💍');
            broadcastState();
        }
    });

    socket.on('CAPTAIN_CHOOSE_INSPECTOR', ({ targetPlayerId }) => {
        const currentState = gameActor.getSnapshot().context;
        // The opposite team captain chooses their inspector to find the ring.
        const isTeamACaptain = currentState.teams.A.captain === socket.id;
        const isTeamBCaptain = currentState.teams.B.captain === socket.id;

        if ((isTeamBCaptain && currentState.currentTurn === 'A') ||
            (isTeamACaptain && currentState.currentTurn === 'B')) {
            gameActor.send({ type: 'CHOOSE_INSPECTOR', targetPlayerId });
            broadcastState();
        }
    });

    socket.on('INSPECTOR_SEARCH', ({ targetPlayerId, hand }) => {
        const currentState = gameActor.getSnapshot().context;
        // targetPlayerId is the person being searched, hand is 'left' or 'right'

        const isHidingTeamA = currentState.currentTurn === 'A';
        const actualRingHolder = isHidingTeamA ? currentState.teams.A.hasRing : currentState.teams.B.hasRing;

        if (targetPlayerId === actualRingHolder) {
            io.emit('SEARCH_RESULT', { success: true, message: 'لكة! 💍 🎉', foundOn: targetPlayerId });
        } else {
            io.emit('SEARCH_RESULT', { success: false, message: 'باتت!', failedOn: targetPlayerId });
        }

        gameActor.send({ type: 'INSPECT', targetPlayerId, hand });
        broadcastState();
    });

    socket.on('disconnect', () => {
        gameActor.send({ type: 'LEAVE', socketId: socket.id });
        broadcastState();
    });
};
