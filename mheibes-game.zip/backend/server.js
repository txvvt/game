const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const setupSocketEvents = require('./socket-events');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);
  setupSocketEvents(io, socket);
  
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    // Cleanup will be handled in socket-events logic
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Mheibes Server is running on port ${PORT}`);
});
