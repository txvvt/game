const { setup, assign, createActor } = require('xstate');

const mheibesMachine = setup({
    types: {
        context: {},
        events: {}
    },
    actions: {
        addPlayer: assign({
            players: ({ context, event }) => {
                return {
                    ...context.players,
                    [event.socketId]: { id: event.socketId, name: event.name, isAdmin: event.isAdmin }
                };
            }
        }),
        removePlayer: assign({
            players: ({ context, event }) => {
                const newPlayers = { ...context.players };
                delete newPlayers[event.socketId];
                return newPlayers;
            },
            teams: ({ context, event }) => {
                const id = event.socketId;
                const newTeams = JSON.parse(JSON.stringify(context.teams));

                const indexA = newTeams.A.members.findIndex(p => p.id === id);
                if (indexA !== -1) newTeams.A.members.splice(indexA, 1);

                const indexB = newTeams.B.members.findIndex(p => p.id === id);
                if (indexB !== -1) newTeams.B.members.splice(indexB, 1);

                return newTeams;
            }
        }),
        assignTeams: assign({
            teams: ({ context }) => {
                const playerKeys = Object.keys(context.players);
                const nonAdmins = playerKeys.filter(id => !context.players[id].isAdmin);
                const shuffled = nonAdmins.sort(() => 0.5 - Math.random());
                const half = Math.ceil(shuffled.length / 2);

                const newTeams = JSON.parse(JSON.stringify(context.teams));
                newTeams.A.members = shuffled.slice(0, half).map(id => context.players[id]);
                newTeams.B.members = shuffled.slice(half).map(id => context.players[id]);
                return newTeams;
            }
        }),
        assignCaptains: assign({
            teams: ({ context, event }) => {
                const newTeams = JSON.parse(JSON.stringify(context.teams));
                newTeams.A.captain = event.captainA;
                newTeams.B.captain = event.captainB;
                return newTeams;
            },
            currentTurn: () => Math.random() > 0.5 ? 'A' : 'B'
        }),
        hideRing: assign({
            teams: ({ context, event }) => {
                const newTeams = JSON.parse(JSON.stringify(context.teams));
                if (context.currentTurn === 'A') {
                    newTeams.A.hasRing = event.targetPlayerId;
                } else {
                    newTeams.B.hasRing = event.targetPlayerId;
                }
                return newTeams;
            }
        }),
        chooseInspector: assign({
            teams: ({ context, event }) => {
                const newTeams = JSON.parse(JSON.stringify(context.teams));
                if (context.currentTurn === 'A') {
                    newTeams.B.inspector = event.targetPlayerId;
                } else {
                    newTeams.A.inspector = event.targetPlayerId;
                }
                return newTeams;
            }
        }),
        handleSearchResult: assign({
            teams: ({ context, event }) => {
                const newTeams = JSON.parse(JSON.stringify(context.teams));
                const actualRingHolder = context.currentTurn === 'A' ? context.teams.A.hasRing : context.teams.B.hasRing;

                if (event.targetPlayerId === actualRingHolder) {
                    // Success! Searcher team gets point
                    if (context.currentTurn === 'A') newTeams.B.score += 1;
                    if (context.currentTurn === 'B') newTeams.A.score += 1;
                } else {
                    // Fail! Hiding team gets point
                    if (context.currentTurn === 'A') newTeams.A.score += 1;
                    if (context.currentTurn === 'B') newTeams.B.score += 1;
                }
                // Reset hiding/inspecting state
                newTeams.A.hasRing = null;
                newTeams.B.hasRing = null;
                newTeams.A.inspector = null;
                newTeams.B.inspector = null;
                return newTeams;
            },
            currentTurn: ({ context, event }) => {
                const actualRingHolder = context.currentTurn === 'A' ? context.teams.A.hasRing : context.teams.B.hasRing;
                if (event.targetPlayerId === actualRingHolder) {
                    // Found it -> switch turns
                    return context.currentTurn === 'A' ? 'B' : 'A';
                }
                return context.currentTurn; // Keep turn if they didn't find it
            }
        })
    }
}).createMachine({
    id: 'mheibes',
    initial: 'LOBBY',
    context: {
        players: {},
        teams: {
            A: { captain: null, members: [], hasRing: null, inspector: null, score: 0 },
            B: { captain: null, members: [], hasRing: null, inspector: null, score: 0 }
        },
        currentTurn: null
    },
    states: {
        LOBBY: {
            on: {
                JOIN: { actions: 'addPlayer' },
                LEAVE: { actions: 'removePlayer' },
                DRAW_TEAMS: { target: 'ASSIGN_CAPTAINS', actions: 'assignTeams' }
            }
        },
        ASSIGN_CAPTAINS: {
            on: {
                JOIN: { actions: 'addPlayer' },
                LEAVE: { actions: 'removePlayer' },
                ASSIGN_CAPTAINS: { target: 'HIDING_RING', actions: 'assignCaptains' }
            }
        },
        HIDING_RING: {
            on: {
                LEAVE: { actions: 'removePlayer' },
                HIDE_RING: { target: 'CHOOSE_INSPECTOR', actions: 'hideRing' }
            }
        },
        CHOOSE_INSPECTOR: {
            on: {
                LEAVE: { actions: 'removePlayer' },
                CHOOSE_INSPECTOR: { target: 'SEARCHING', actions: 'chooseInspector' }
            }
        },
        SEARCHING: {
            on: {
                LEAVE: { actions: 'removePlayer' },
                INSPECT: { target: 'HIDING_RING', actions: 'handleSearchResult' }
            }
        }
    }
});

const gameActor = createActor(mheibesMachine);
gameActor.start();

const getPublicState = () => {
    const currentState = gameActor.getSnapshot();
    const publicState = {
        gameState: currentState.value,
        players: currentState.context.players,
        teams: JSON.parse(JSON.stringify(currentState.context.teams)),
        currentTurn: currentState.context.currentTurn
    };

    // Hide ring from public payload
    publicState.teams.A.hasRing = null;
    publicState.teams.B.hasRing = null;

    return publicState;
};

module.exports = {
    gameActor,
    getPublicState
};
