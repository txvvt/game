/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'baghdad-wood': '#3E2723',
                'baghdad-wood-light': '#5D4037',
                'baghdad-gold': '#FFD54F',
                'baghdad-gold-dark': '#FFC107',
                'baghdad-accent': '#8D6E63',
                'baghdad-bg': '#EFEBE9',
            },
            fontFamily: {
                'arabic': ['Tajawal', 'Cairo', 'sans-serif'],
            },
            backgroundImage: {
                'cafe-pattern': "url('https://www.transparenttextures.com/patterns/wood-pattern.png')",
            }
        },
    },
    plugins: [],
}
