import React from 'react';
import { useGame } from './context/GameContext';
import Login from './components/Login';
import Lobby from './components/Lobby';
import Board from './components/Board';

const App: React.FC = () => {
  const { gameState, playerId, playerName } = useGame();

  if (!playerId || !playerName) {
    return <Login />;
  }

  if (!gameState || gameState.gameState === 'LOBBY') {
    return <Lobby />;
  }

  return (
    <div className="min-h-screen">
      <header className="bg-baghdad-wood text-baghdad-gold p-4 shadow-lg text-center relative">
        <h1 className="text-3xl font-bold font-arabic drop-shadow-md">لعبة المحيبس - كاهوة بغداد</h1>
        <div className="absolute left-4 top-4 text-white text-sm bg-baghdad-wood-light px-3 py-1 rounded-full">
          لاعب: {playerName}
        </div>
      </header>
      <main>
        <Board />
      </main>
    </div>
  );
};

export default App;
