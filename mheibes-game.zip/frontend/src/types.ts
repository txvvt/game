export type GameStatePhase = 'LOBBY' | 'ASSIGN_CAPTAINS' | 'HIDING_RING' | 'CHOOSE_INSPECTOR' | 'SEARCHING' | 'ROUND_END';

export interface Player {
    id: string;
    name: string;
    isAdmin: boolean;
}

export interface Team {
    captain: string | null;
    members: Player[];
    inspector: string | null;
    score: number;
}

export interface GameState {
    gameState: GameStatePhase;
    players: Record<string, Player>;
    teams: {
        A: Team;
        B: Team;
    };
    currentTurn: 'A' | 'B' | null;
}

export interface SearchResult {
    success: boolean;
    message: string;
    foundOn?: string;
    failedOn?: string;
}
