import React, { useState } from 'react';
import { useGame } from '../context/GameContext';

const Login: React.FC = () => {
    const [name, setName] = useState('');
    const [isAdminLogin, setIsAdminLogin] = useState(false);
    const { joinGame } = useGame();

    const handleJoin = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            joinGame(name.trim(), isAdminLogin);
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen">
            <div className="cafe-card max-w-md w-full text-center">
                <h1 className="text-4xl font-bold text-baghdad-gold-dark mb-2 drop-shadow-md">لعبة المحيبس</h1>
                <p className="text-baghdad-wood-light mb-8">أهلاً بك في مقهى بغداد، سجل اسمك للدخول</p>

                <form onSubmit={handleJoin} className="flex flex-col gap-4">
                    <input
                        type="text"
                        className="w-full px-4 py-3 rounded-lg border-2 border-baghdad-wood focus:outline-none focus:border-baghdad-gold text-xl"
                        placeholder="الاسم (مثال: علي)"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        autoFocus
                    />

                    <label className="flex items-center justify-center gap-2 text-lg text-baghdad-wood cursor-pointer">
                        <input
                            type="checkbox"
                            className="w-5 h-5 accent-baghdad-wood"
                            checked={isAdminLogin}
                            onChange={(e) => setIsAdminLogin(e.target.checked)}
                        />
                        تسجيل كمدير (أدمن)
                    </label>

                    <button type="submit" className="btn-primary mt-4 text-xl py-3">
                        دخول للمقهى ☕
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Login;
