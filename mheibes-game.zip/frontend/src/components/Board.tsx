import React, { useState } from 'react';
import { useGame } from '../context/GameContext';

const Board: React.FC = () => {
    const {
        gameState, playerId, isAdmin,
        adminAssignCaptains, captainHideRing,
        captainChooseInspector, inspectorSearch
    } = useGame();

    const [capA, setCapA] = useState('');
    const [capB, setCapB] = useState('');
    const [selectedInspectTarget, setSelectedInspectTarget] = useState<string | null>(null);

    if (!gameState) return null;

    const { teams, currentTurn, gameState: phase } = gameState;

    const isTeamACaptain = teams.A.captain === playerId;
    const isTeamBCaptain = teams.B.captain === playerId;
    const isTeamAInspector = teams.A.inspector === playerId;
    const isTeamBInspector = teams.B.inspector === playerId;

    const renderAdminControls = () => {
        if (phase !== 'ASSIGN_CAPTAINS' || !isAdmin) return null;
        return (
            <div className="cafe-card w-full mb-8 border-baghdad-gold border-2">
                <h3 className="text-xl font-bold mb-4 text-center">أدمن: اختر كباتن الفرق</h3>
                <div className="flex gap-4 justify-center">
                    <select className="p-2 rounded border" value={capA} onChange={e => setCapA(e.target.value)}>
                        <option value="">كابتن فريق أ</option>
                        {teams.A.members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                    <select className="p-2 rounded border" value={capB} onChange={e => setCapB(e.target.value)}>
                        <option value="">كابتن فريق ب</option>
                        {teams.B.members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                    <button
                        className="btn-gold"
                        disabled={!capA || !capB}
                        onClick={() => adminAssignCaptains(capA, capB)}
                    >
                        تأكيد الكباتن ✔️
                    </button>
                </div>
            </div>
        );
    };

    const renderCaptainHide = () => {
        if (phase !== 'HIDING_RING') return null;
        let myTeam = null;
        if (isTeamACaptain && currentTurn === 'A') myTeam = teams.A;
        if (isTeamBCaptain && currentTurn === 'B') myTeam = teams.B;

        if (!myTeam) return (
            <div className="text-center py-4 text-xl">
                {currentTurn === 'A' ? 'كابتن فريق أ يوزع المحيبس...' : 'كابتن فريق ب يوزع المحيبس...'}
            </div>
        );

        return (
            <div className="cafe-card bg-baghdad-wood text-white mb-8 border-2 border-baghdad-gold text-center">
                <h3 className="text-2xl mb-4 font-bold text-baghdad-gold">أنت الكابتن يا بطل! لمن تنطي المحيبس؟</h3>
                <div className="flex flex-wrap justify-center gap-3">
                    {myTeam.members.map(m => (
                        <button key={m.id} onClick={() => captainHideRing(m.id)} className="btn-gold text-lg">
                            {m.name}
                        </button>
                    ))}
                </div>
            </div>
        );
    };

    const renderCaptainInspect = () => {
        if (phase !== 'CHOOSE_INSPECTOR') return null;

        let myTeam = null;
        // Opposite team captain chooses the inspector
        if (isTeamACaptain && currentTurn === 'B') myTeam = teams.A;
        if (isTeamBCaptain && currentTurn === 'A') myTeam = teams.B;

        if (!myTeam) return (
            <div className="text-center py-4 text-xl">
                يتم اختيار (الطاير) للتفتيش...
            </div>
        );

        return (
            <div className="cafe-card bg-baghdad-wood text-white mb-8 text-center">
                <h3 className="text-2xl mb-4 font-bold text-baghdad-gold">منو راح ينزل يفتش عن المحيبس؟</h3>
                <div className="flex flex-wrap justify-center gap-3">
                    {myTeam.members.map(m => (
                        <button key={m.id} onClick={() => captainChooseInspector(m.id)} className="btn-gold text-lg">
                            اختيار {m.name} للطيران
                        </button>
                    ))}
                </div>
            </div>
        );
    };

    const renderTeamList = (team: typeof teams.A, title: string, teamLabel: 'A' | 'B') => {
        const isOppositeTeam = (teamLabel === 'A' && currentTurn === 'B') || (teamLabel === 'B' && currentTurn === 'A');
        const isMyTurnToInspect = (teamLabel === 'B' && isTeamAInspector) || (teamLabel === 'A' && isTeamBInspector);
        const canClickToInspect = phase === 'SEARCHING' && isMyTurnToInspect;

        return (
            <div className="cafe-card flex-1 min-w-[300px]">
                <h2 className="text-2xl font-bold bg-baghdad-wood text-baghdad-gold p-3 rounded-t-lg -mx-6 -mt-6 rounded-b-none mb-4 flex justify-between">
                    <span>{title}</span>
                    <span>نقاط: {team.score}</span>
                </h2>
                {team.captain && (
                    <div className="mb-4 text-center">
                        <span className="bg-baghdad-wood-light text-white px-3 py-1 rounded-full text-sm">
                            الكابتن: {team.members.find(m => m.id === team.captain)?.name}
                        </span>
                    </div>
                )}
                <div className="grid grid-cols-2 gap-3">
                    {team.members.map(m => (
                        <button
                            key={m.id}
                            disabled={!canClickToInspect}
                            onClick={() => canClickToInspect ? setSelectedInspectTarget(m.id) : null}
                            className={`p-3 rounded-lg border-2 font-bold text-lg transition-all ${canClickToInspect
                                    ? 'border-baghdad-gold hover:bg-baghdad-gold hover:text-baghdad-wood cursor-pointer bg-white text-baghdad-wood'
                                    : 'border-baghdad-wood/20 bg-baghdad-bg text-baghdad-wood cursor-default'
                                }`}
                        >
                            {m.name}
                            {m.id === team.inspector && <span className="block text-xs text-red-600">🕵️ المفتش</span>}
                            {m.id === selectedInspectTarget && canClickToInspect && (
                                <div className="mt-2 flex gap-1 justify-center z-10 relative">
                                    <div className="bg-baghdad-wood text-white px-2 py-1 rounded text-sm hover:bg-baghdad-gold" onClick={(e) => { e.stopPropagation(); inspectorSearch(m.id, 'right'); setSelectedInspectTarget(null); }}>يمين</div>
                                    <div className="bg-baghdad-wood text-white px-2 py-1 rounded text-sm hover:bg-baghdad-gold" onClick={(e) => { e.stopPropagation(); inspectorSearch(m.id, 'left'); setSelectedInspectTarget(null); }}>يسار</div>
                                </div>
                            )}
                        </button>
                    ))}
                </div>
            </div>
        );
    };

    return (
        <div className="max-w-6xl mx-auto p-4 pt-8">

            {renderAdminControls()}
            {renderCaptainHide()}
            {renderCaptainInspect()}

            {phase === 'SEARCHING' && (isTeamAInspector || isTeamBInspector) && (
                <div className="text-center font-bold text-2xl text-red-600 drop-shadow mb-8 bg-white/80 py-2 rounded-lg">
                    أنت الطاير! إضغط على الكسوجة للبحث...
                </div>
            )}

            <div className="flex flex-col md:flex-row gap-8 mt-8">
                {renderTeamList(teams.A, 'فريق أ', 'A')}
                <div className="hidden flex-col justify-center items-center md:flex font-bold text-baghdad-gold text-4xl drop-shadow">
                    VS
                </div>
                {renderTeamList(teams.B, 'فريق ب', 'B')}
            </div>
        </div>
    );
};

export default Board;
