import React from 'react';
import { useGame } from '../context/GameContext';

const Lobby: React.FC = () => {
    const { gameState, isAdmin, adminDrawTeams } = useGame();

    if (!gameState) return null;

    const players = Object.values(gameState.players);
    const admins = players.filter(p => p.isAdmin);
    const regularPlayers = players.filter(p => !p.isAdmin);

    return (
        <div className="flex flex-col items-center justify-start min-h-screen pt-12 px-4">
            <div className="cafe-card w-full max-w-3xl">
                <h2 className="text-3xl font-bold text-center text-baghdad-gold-dark mb-6">مرحلة التجمع (الگعدة)</h2>

                <div className="mb-8">
                    <h3 className="text-xl font-bold bg-baghdad-wood text-white px-4 py-2 rounded-t-lg">اللاعبين المتصلين ({regularPlayers.length})</h3>
                    <div className="border-2 border-baghdad-wood rounded-b-lg p-4 bg-white min-h-[100px] flex flex-wrap gap-2">
                        {regularPlayers.map(p => (
                            <span key={p.id} className="bg-baghdad-bg text-baghdad-wood px-3 py-1 rounded-full font-bold shadow-sm">
                                {p.name}
                            </span>
                        ))}
                        {regularPlayers.length === 0 && <span className="text-gray-500 w-full text-center">ننتظر وصول الشباب...</span>}
                    </div>
                </div>

                {isAdmin && (
                    <div className="text-center mt-8">
                        <button
                            onClick={adminDrawTeams}
                            disabled={regularPlayers.length < 2}
                            className="btn-gold text-2xl py-3 px-8 shadow-lg"
                        >
                            سوي قرعة و وزع الفرق 🎲
                        </button>
                        {regularPlayers.length < 2 && <p className="text-red-500 mt-2 text-sm">نحتاج على الأقل لاعبين للبدء</p>}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Lobby;
